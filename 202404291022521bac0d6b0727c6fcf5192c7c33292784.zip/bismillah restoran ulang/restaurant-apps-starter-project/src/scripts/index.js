import 'regenerator-runtime'; 
import '../styles/main.css';
import restaurants from '../public/data/DATA.json';

const restaurantList = document.querySelector('.restaurant-list');
const hamburgerButtonElement = document.querySelector('#hamburger');
const drawerElement = document.querySelector('#drawer');
const mainElement = document.querySelector('main');
 
hamburgerButtonElement.addEventListener('click', event => {
  drawerElement.classList.toggle('open');
  event.stopPropagation();
});
 
mainElement.addEventListener('click', event => {
  drawerElement.classList.remove('open');
  event.stopPropagation();
})

restaurants.restaurants.forEach((restaurant) => {
    restaurantList.innerHTML += `
        <div class="restaurant">
            <div class="city">City: ${restaurant.city}</div>
            <img src="${restaurant.pictureId}" alt="${restaurant.name}">
            <h3>Rating: ${restaurant.rating}<h3>
            <h2>${restaurant.name}</h2>
            <p>${restaurant.description.substring(0, 5000)}</p>
        </div>
    `;
});
