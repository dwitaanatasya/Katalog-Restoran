/* eslint-disable linebreak-style */
/* eslint-disable no-trailing-spaces */

const assert = require('assert');
// eslint-disable-next-line no-undef
Feature('Liking Restaurants');
// eslint-disable-next-line no-undef
Before(({ I }) => {
  I.amOnPage('/');
  I.waitForElement('.restaurant-item__content a', 20); // Increased timeout to 20 seconds
  console.log('Navigated to home page');
});
// eslint-disable-next-line no-undef
Scenario('showing empty liked restaurants', ({ I }) => {
  I.amOnPage('/#/favorite');
  I.waitForElement('.restaurant-item__not__found', 20); // Increased timeout to 20 seconds
  console.log('Navigated to liked restaurants page');
  
  I.see('Tidak ada restoran untuk ditampilkan', '.restaurant-item__not__found');
  console.log('Checked empty liked restaurants');
  I.saveScreenshot('empty-liked.png');
});
// eslint-disable-next-line no-undef
Scenario('liking one restaurant', async ({ I }) => {
  I.amOnPage('/');
  I.waitForElement('.restaurant-item__content a', 20); // Increased timeout to 20 seconds
  console.log('Navigated to home page');

  const restaurantCount = await I.grabNumberOfVisibleElements('.restaurant-item__content a');
  console.log(`Number of restaurants found: ${restaurantCount}`);

  I.seeElement('.restaurant-item__content a');
  // eslint-disable-next-line no-undef
  const firstRestaurant = locate('.restaurant-item__content a').first();
  const firstRestaurantName = (await I.grabTextFrom(firstRestaurant)).trim();
  console.log(`First restaurant name: ${firstRestaurantName}`);
  
  I.click(firstRestaurant);
  I.waitForElement('#likeButton', 20); // Increased timeout to 20 seconds
  console.log('Clicked on the first restaurant');

  I.seeElement('#likeButton');
  I.click('#likeButton');
  I.waitForElement('#likeButton[aria-label="unlike this restaurant"]', 20); // Increased timeout to 20 seconds
  console.log('Clicked on like button');

  I.amOnPage('/#/favorite');
  I.waitForElement('.restaurant-item', 20); // Increased timeout to 20 seconds
  console.log('Navigated to liked restaurants page');
  
  I.seeElement('.restaurant-item');
  const likedRestaurantName = (await I.grabTextFrom('.restaurant-item__content')).trim();
  console.log(`Liked restaurant name: ${likedRestaurantName}`);

  I.saveScreenshot('one-restaurant-liked.png');
  assert.strictEqual(firstRestaurantName, likedRestaurantName.split('\n')[0].trim()); // Compare only the name part
});
