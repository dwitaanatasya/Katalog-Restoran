import CONFIG from './config';

function foodsRestaurant(restaurant) {
  return restaurant.menus.foods
    .map(
      (food) => `
      <li>${food.name}</li>
      `,
    )
    .join('');
}

function categoriesRestaurant(restaurant) {
  return restaurant.categories
    .map(
      (category) => `
      <li>${category.name}</li>
    `,
    )
    .join('');
}

function drinksRestaurant(restaurant) {
  return restaurant.menus.drinks
    .map(
      (drink) => `
      <li>${drink.name}</li>
      `,
    )
    .join('');
}

function reviewCustomer(customerReview) {
  return customerReview
    .map(
      (review) => `
      <li class="review">
        <div class="name-rev">${review.name}</div>
        <div class="date-rev">${review.date}</div>
        <div class="description-rev">"${review.review}"</div>
      </li>
    `,
    )
    .join('');
}

const createRestaurantDetailTemplate = (restaurant) => `
  <div class="detail">
    <img class="detail__poster lazyload" data-src="${CONFIG.BASE_IMAGE_URL + restaurant.pictureId}" alt="${restaurant.name}" />
    <div class="detail__info">
      <h2 class="restaurant__title">${restaurant.name}</h2>
      <h3 class="detail__info-title">Information</h3>
      <h4>Alamat</h4>
      <p>${restaurant.address}</p>
      <h4>Kota</h4>
      <p>${restaurant.city}</p>
      <h4>Rating</h4>
      <p>${restaurant.rating}</p>
      <h4>Categories</h4>
      <ul>
        ${categoriesRestaurant(restaurant)}
      </ul>
    </div>
    <div class="restaurant__overview">
      <h3>Deskripsi</h3>
      <p>${restaurant.description}</p>
      <h3>Foods Menu</h3>
      <ul>
        ${foodsRestaurant(restaurant)}
      </ul>
      <h3>Drinks Menu</h3>
      <ul>
        ${drinksRestaurant(restaurant)}
      </ul>
    </div>
    <div class="customer-reviews">
      <h3>Customer Reviews</h3>
      <ul id="custReviews">
        ${reviewCustomer(restaurant.customerReviews)}
      </ul>
      <div class="add-review">
        <h4>Add Review</h4>
        <div class="input-review">
          <label for="rev-name">Name</label>
          <input type="text" id="rev-name" name="rev-name" placeholder="Name" />
          <label for="rev-content">Review</label>
          <textarea name="rev-content" id="rev-content" placeholder="Write your review here"></textarea>
          <button id="submit-review" onclick="window.tambahReview()">Submit</button>
        </div>
      </div>
    </div>
  </div>
`;

const createRestaurantItemTemplate = (restaurant) => `
  <article class="restaurant-item">
    <img class="restaurant-item__thumbnail lazyload" data-src="${CONFIG.BASE_IMAGE_URL + restaurant.pictureId}" alt="${restaurant.name}">
    <div class="restaurant-item__content">
      <h3><a href="${`/#/detail/${restaurant.id}`}">${restaurant.name}</a></h3>
      <p>Rating: ${restaurant.rating}</p>
      <p>Kota: ${restaurant.city}</p>
      <p>${restaurant.description}</p>
    </div>
  </article>
`;

export {
  createRestaurantDetailTemplate,
  createRestaurantItemTemplate,
};
