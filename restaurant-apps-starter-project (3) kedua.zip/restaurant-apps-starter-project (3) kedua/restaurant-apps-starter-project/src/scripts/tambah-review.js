import RestaurantSource from './data-source';
import UrlParser from './url-parser';

const tambahReview = async () => {
  const url = UrlParser.parseActiveUrlWithoutCombiner();
  const reviewName = document.getElementById('rev-name');
  const reviewContent = document.getElementById('rev-content');
  const reviewContainer = document.querySelector('#custReviews');

  const dataInput = {
    id: url.id,
    name: reviewName.value,
    review: reviewContent.value,
  };

  const date = new Date().toLocaleDateString('id-ID', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

  const newReview = `
    <li class="review">
      <div class="name-rev">${dataInput.name}</div>
      <div class="date-rev">${date}</div>
      <div class="description-rev">"${dataInput.review}"</div>
    </li>
  `;

  await RestaurantSource.addReview(dataInput);
  reviewContainer.innerHTML += newReview;
  reviewName.value = '';
  reviewContent.value = '';
};

export default tambahReview;
