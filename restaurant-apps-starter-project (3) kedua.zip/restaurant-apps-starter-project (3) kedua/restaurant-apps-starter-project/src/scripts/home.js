import dataSource from './data-source';
import CONFIG from './config';
import { createRestaurantItemTemplate } from './template-creator';

class Home {
  static async render() {
    return `      
        <picture class="hero">
            <source media="(max-width: 600px)" srcset="/heros/hero-image_1-small.jpg">
            <img class="lazyload" data-src="/heros/hero-image_1-large.jpg" alt="hero atau awalan">
        </picture>
        <h2>Explore Restaurant</h2>
        <div class="restaurant-list" id="restaurant-list"></div>`;
  }

  static async afterRender() {
    try {
      const restaurants = await dataSource.home();
      const restaurantsContainer = document.querySelector('#restaurant-list');

      if (!restaurantsContainer) {
        throw new Error('Container element not found');
      }

      restaurants.forEach((restaurant) => {
        restaurantsContainer.innerHTML += createRestaurantItemTemplate(restaurant);
      });

      if (restaurants.length === 0) {
        restaurantsContainer.innerHTML = '<p class="restaurant-item__not__found">Tidak ada restoran untuk ditampilkan</p>';
      }
    } catch (error) {
      console.error('Error occurred in afterRender:', error);
    }
  }
}

export default Home;
