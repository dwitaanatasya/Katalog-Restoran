import Home from './home';
import Favorite from './favorite';
import Detail from './detail';

const routes = {
  '/': Home,
  '/home': Home,
  '/favorite': Favorite,
  '/detail/:id': Detail,
};

const route = async () => {
  const url = window.location.hash.slice(1).toLowerCase() || '/';
  const urlSplit = url.split('/');
  const urlCombiner = (urlSplit.length > 1 && urlSplit[1] === 'detail') ? `/${urlSplit[1]}/:id` : `/${urlSplit[1] || ''}`;

  const page = routes[urlCombiner];
  document.querySelector('main').innerHTML = await page.render();
  await page.afterRender();
};

export default route;
