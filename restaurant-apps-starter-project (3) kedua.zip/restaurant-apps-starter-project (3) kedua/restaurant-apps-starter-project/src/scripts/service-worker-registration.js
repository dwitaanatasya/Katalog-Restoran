import { Workbox } from "workbox-window";

export const swRegister = () => {
  if (!("serviceWorker" in navigator)) {
    console.log('Service Worker not supported in the browser');
    return;
  }
  window.addEventListener("load", async () => {
    const wb = new Workbox("/service-worker.js");
    try {
      await wb.register();
      console.log("Service worker registered");
    } catch (error) {
      console.error("Failed to register service worker:", error);
    }
  });
};
export default swRegister;
