import { expect, it } from '@jest/globals';

const itActsAsFavoriteModel = (Favorite) => {
  it('should return the restaurant that has been added', async () => {
    await Favorite.putRestaurant({ id: 1 });
    await Favorite.putRestaurant({ id: 2 });

    expect(await Favorite.getRestaurant(1)).toEqual({ id: 1 });
    expect(await Favorite.getRestaurant(2)).toEqual({ id: 2 });
    expect(await Favorite.getRestaurant(3)).toEqual(undefined);
  });

  it('can return all of the restaurants that have been added', async () => {
    await Favorite.putRestaurant({ id: 1 });
    await Favorite.putRestaurant({ id: 2 });

    expect(await Favorite.getAllRestaurants()).toEqual([{ id: 1 }, { id: 2 }]);
  });

  it('should remove favorite restaurant', async () => {
    await Favorite.putRestaurant({ id: 1 });
    await Favorite.putRestaurant({ id: 2 });
    await Favorite.putRestaurant({ id: 3 });

    await Favorite.deleteRestaurant(1);

    expect(await Favorite.getAllRestaurants()).toEqual([{ id: 2 }, { id: 3 }]);
  });

  it('should handle request to remove a restaurant even though the restaurant has not been added', async () => {
    await Favorite.putRestaurant({ id: 1 });
    await Favorite.putRestaurant({ id: 2 });
    await Favorite.putRestaurant({ id: 3 });

    await Favorite.deleteRestaurant(4);

    expect(await Favorite.getAllRestaurants()).toEqual([{ id: 1 }, { id: 2 }, { id: 3 }]);
  });
};

// eslint-disable-next-line import/prefer-default-export
export { itActsAsFavoriteModel };
