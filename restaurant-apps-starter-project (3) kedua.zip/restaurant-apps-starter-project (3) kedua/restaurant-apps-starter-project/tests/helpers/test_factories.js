import tombolLike from "../../src/scripts/tombol-like";
import dbFavorite from "../../src/scripts/db-favorite";

const createTombolLike = async (restaurant) => {
    await tombolLike.init({
        likeButtonContainer: document.querySelector('#likeButtonContainer'),
        restaurant,
        dbFavorite
    });
};

// eslint-disable-next-line import/prefer-default-export
export { createTombolLike };
