import {
    afterEach,
    describe,
  } from '@jest/globals';
  import dbFavorite from '../src/scripts/db-favorite'; // Mengimpor dbFavorite
  import { itActsAsFavoriteModel } from './contracts/favorire_restaurant_contract';

  describe('Favorite Restaurant Idb Contract Test Implementation', () => {
    afterEach(async () => {
      (await dbFavorite.getAllRestaurants()).forEach(async (restaurant) => {
        await dbFavorite.deleteRestaurant(restaurant.id); // Menggunakan dbFavorite
      });
    });

    itActsAsFavoriteModel(dbFavorite); // Menggunakan dbFavorite
  });
