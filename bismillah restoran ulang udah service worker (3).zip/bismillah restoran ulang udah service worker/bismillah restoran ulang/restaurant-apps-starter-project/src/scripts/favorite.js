import dbFavorite from './db-favorite';
import { createRestaurantItemTemplate } from './template-creator';

const Favorite = {
  async render() {
    return `
        <div class="restaurant-list" id="restaurant-list"></div>
        `;
  },

  async afterRender() {
    try {
      const restaurants = await dbFavorite.getAllRestaurants();
      const restaurantsContainer = document.querySelector('#restaurant-list');

      if (!restaurantsContainer) {
        throw new Error('Container element not found');
      }

      restaurants.forEach((restaurant) => {
        restaurantsContainer.innerHTML += createRestaurantItemTemplate(restaurant);
      });
    } catch (error) {
      console.error('Error occurred in afterRender:', error);
    }
  },
};

export default Favorite;
