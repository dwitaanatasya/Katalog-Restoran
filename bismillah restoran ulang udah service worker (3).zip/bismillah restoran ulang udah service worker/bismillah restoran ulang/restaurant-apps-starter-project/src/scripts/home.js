import dataSource from './data-source';
import { createRestaurantItemTemplate } from './template-creator';

const Home = {
  async render() {
    return `      
        <div class="hero">
            <img src="../images/heros/hero-image_1.jpg" alt="hero atau awalan">
        </div>
        <h2>Explore Restaurant</h2>
        <div class="restaurant-list" id="restaurant-list"></div>`;
  },
  async afterRender() {
    try {
      const restaurants = await dataSource.home();
      const restaurantsContainer = document.querySelector('#restaurant-list');

      if (!restaurantsContainer) {
        throw new Error('Container element not found');
      }

      restaurants.forEach((restaurant) => {
        restaurantsContainer.innerHTML += createRestaurantItemTemplate(restaurant);
      });
    } catch (error) {
      console.error('Error occurred in afterRender:', error);
    }
  },
};

export default Home;
