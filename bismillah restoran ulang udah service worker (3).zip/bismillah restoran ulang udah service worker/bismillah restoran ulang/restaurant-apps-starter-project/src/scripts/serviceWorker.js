const CACHE_NAME = 'dwita-restaurant-apps-cache-v1';
const urlsToCache = [
  '/',
  '/index.html',
  '/src/public/webmanifest.json',
  '/src/public/images/heros/hero-image_1.jpg',
  '/src/styles/main.css',
  '/src/scripts/config.js',
  '/src/scripts/api-endpoint.js',
  '/src/scripts/app.bundle.js',
  '/src/public/images/icons/icon-72x72.png',
  '/src/public/images/icons/icon-96x96.png',
  '/src/public/images/icons/icon-128x128.png',
  '/src/public/images/icons/icon-144x144.png',
  '/src/public/images/icons/icon-152x152.png',
  '/src/public/images/icons/icon-192x192.png',
  '/src/public/images/icons/icon-384x384.png',
  '/src/public/images/icons/icon-512x512.png',
];

self.addEventListener('install', (event) => {
  console.log('Installing Service Worker ...');
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(urlsToCache)).catch((error) => {
      console.error('Failed to cache resources:', error);
    }),
  );
});

self.addEventListener('activate', (event) => {
  console.log('Activating Service Worker ...');
  event.waitUntil(
    caches.keys().then((cacheNames) => Promise.all(
      cacheNames.filter((cacheName) => cacheName !== CACHE_NAME).map((cacheName) => caches.delete(cacheName)),
    )),
  );
});

self.addEventListener('fetch', (event) => {
  console.log(event.request);

  event.respondWith(fetch(event.request));
  if (event.request.url.startsWith(self.location.origin)) {
    event.respondWith(
      caches.match(event.request).then((response) => {
        if (response) {
          return response;
        }
        return fetch(event.request).then((response) => {
          if (!response || response.status !== 200 || response.type !== 'basic') {
            return response;
          }
          const responseToCache = response.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, responseToCache);
          });
          return response;
        });
      }),
    );
  }
});
